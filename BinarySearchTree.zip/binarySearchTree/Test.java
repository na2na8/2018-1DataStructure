package binarySearchTree;

import java.util.ArrayList;



public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinarySearchTree bst = new BinarySearchTree();
		ArrayList<Integer> arrBST = new ArrayList<>();
		ArrayList<Integer> arrBT = new ArrayList<>();
		
		bst.insertBST(1);
		bst.insertBST(4);
		bst.insertBST(5);
		bst.insertBST(2);
		bst.insertBST(3);
		
		
		BinaryTree T = new BinaryTree();
		TreeNode n1 = T.makeBT(null, 1, null);
		TreeNode n2 = T.makeBT(null, 4, null);
		TreeNode n3 = T.makeBT(null, 5, null);
		TreeNode n4 = T.makeBT(n1, 2, n2);
		TreeNode n5 = T.makeBT(n4, 3, n3);
		
		
		System.out.println("\na. Binary SearchTree >>> ");
		arrBST = bst.printBST();
		
		System.out.println("\nb. BinaryTree >>> ");
		arrBT = T.inorder(n5);
		
		System.out.println("\n");
		
		if(IsBST(arrBST, arrBT)) {
			System.out.println("b�� a�� �����Ƿ� BinarySearchTree�Դϴ�.");
		} else {
			System.out.println("b�� a�� ���� �����Ƿ� BinarySearchTree�� �ƴմϴ�.");
		}
		
		
	}
	
	public static boolean IsBST(ArrayList<Integer> a, ArrayList<Integer> b) {
		if(a == b)
			return true;
		else
			return false;
	}
}
