package binarySearchTree;

import java.util.ArrayList;

public class BinaryTree {
	private TreeNode root;
	ArrayList<Integer> arrBT = new ArrayList<>();
	
	public TreeNode makeBT(TreeNode bt1, int data, TreeNode bt2) {
		TreeNode root = new TreeNode();
		root.data = data;
		root.left = bt1;
		root.right = bt2;
		return root;
	}
	
	public ArrayList<Integer> inorder (TreeNode root) {
		if(root != null) {
			inorder(root.left);
			System.out.printf(" %d", root.data);
			save(root.data);
			inorder(root.right);
		}
		return arrBT;
	}
	
	public void save(int x) {
		arrBT.add(x);
	}
}
